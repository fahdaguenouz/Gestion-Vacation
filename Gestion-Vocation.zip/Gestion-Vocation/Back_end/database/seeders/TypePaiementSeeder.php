<?php

namespace Database\Seeders;

use App\Models\TypePaiement;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TypePaiementSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('type_paiements')->insert([
            ['IdTypePaiement' => 1,'Libelle' => 'Bac', 'PrixParCopie' => 1.00,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 2,'Libelle' => 'Primary', 'PrixParCopie' => 0.75,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 3,'Libelle' => 'Secondaire', 'PrixParCopie' => 0.85,'created_at' => now(), 'updated_at' =>now()], 
        ]);
    }
}

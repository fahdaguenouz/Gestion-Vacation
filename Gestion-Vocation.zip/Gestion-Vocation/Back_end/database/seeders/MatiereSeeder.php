<?php

namespace Database\Seeders;

use App\Models\Matiere;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MatiereSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $matieres = [
            ['CodeMatiere' => 'MAT001', 'LibelleAr' => 'الرياضيات', 'LibelleFr' => 'Mathématiques','IdTypePaiement'=>1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT002', 'LibelleAr' => 'الفيزياء', 'LibelleFr' => 'Physique','IdTypePaiement'=>1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT003', 'LibelleAr' => 'الكيمياء', 'LibelleFr' => 'Chimie','IdTypePaiement'=>1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT004', 'LibelleAr' => 'علوم الحياة والأرض', 'LibelleFr' => 'Sciences de la vie et de la terre','IdTypePaiement'=>1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT005', 'LibelleAr' => 'التاريخ والجغرافيا', 'LibelleFr' => 'Histoire et Géographie','IdTypePaiement'=>1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT006', 'LibelleAr' => 'اللغة العربية', 'LibelleFr' => 'Langue Arabe','IdTypePaiement'=>1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT007', 'LibelleAr' => 'اللغة الفرنسية', 'LibelleFr' => 'Langue Française','IdTypePaiement'=>1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT008', 'LibelleAr' => 'اللغة الإنجليزية', 'LibelleFr' => 'Langue Anglaise','IdTypePaiement'=>1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT009', 'LibelleAr' => 'التربية الإسلامية', 'LibelleFr' => 'Éducation Islamique','IdTypePaiement'=>1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT010', 'LibelleAr' => 'التربية الفنية', 'LibelleFr' => 'Éducation Artistique','IdTypePaiement'=>1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT001', 'LibelleAr' => 'الرياضيات', 'LibelleFr' => 'Mathématiques','IdTypePaiement'=>2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT002', 'LibelleAr' => 'الفيزياء', 'LibelleFr' => 'Physique','IdTypePaiement'=>2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT003', 'LibelleAr' => 'الكيمياء', 'LibelleFr' => 'Chimie','IdTypePaiement'=>2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT004', 'LibelleAr' => 'علوم الحياة والأرض', 'LibelleFr' => 'Sciences de la vie et de la terre','IdTypePaiement'=>2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT005', 'LibelleAr' => 'التاريخ والجغرافيا', 'LibelleFr' => 'Histoire et Géographie','IdTypePaiement'=>2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT006', 'LibelleAr' => 'اللغة العربية', 'LibelleFr' => 'Langue Arabe','IdTypePaiement'=>2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT007', 'LibelleAr' => 'اللغة الفرنسية', 'LibelleFr' => 'Langue Française','IdTypePaiement'=>2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT008', 'LibelleAr' => 'اللغة الإنجليزية', 'LibelleFr' => 'Langue Anglaise','IdTypePaiement'=>2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT009', 'LibelleAr' => 'التربية الإسلامية', 'LibelleFr' => 'Éducation Islamique','IdTypePaiement'=>2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT010', 'LibelleAr' => 'التربية الفنية', 'LibelleFr' => 'Éducation Artistique','IdTypePaiement'=>2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT001', 'LibelleAr' => 'الرياضيات', 'LibelleFr' => 'Mathématiques','IdTypePaiement'=>3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT002', 'LibelleAr' => 'الفيزياء', 'LibelleFr' => 'Physique','IdTypePaiement'=>3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT003', 'LibelleAr' => 'الكيمياء', 'LibelleFr' => 'Chimie','IdTypePaiement'=>3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT004', 'LibelleAr' => 'علوم الحياة والأرض', 'LibelleFr' => 'Sciences de la vie et de la terre','IdTypePaiement'=>3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT005', 'LibelleAr' => 'التاريخ والجغرافيا', 'LibelleFr' => 'Histoire et Géographie','IdTypePaiement'=>3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT006', 'LibelleAr' => 'اللغة العربية', 'LibelleFr' => 'Langue Arabe','IdTypePaiement'=>3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT007', 'LibelleAr' => 'اللغة الفرنسية', 'LibelleFr' => 'Langue Française','IdTypePaiement'=>3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT008', 'LibelleAr' => 'اللغة الإنجليزية', 'LibelleFr' => 'Langue Anglaise','IdTypePaiement'=>3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT009', 'LibelleAr' => 'التربية الإسلامية', 'LibelleFr' => 'Éducation Islamique','IdTypePaiement'=>3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeMatiere' => 'MAT010', 'LibelleAr' => 'التربية الفنية', 'LibelleFr' => 'Éducation Artistique','IdTypePaiement'=>3,'created_at' => now(), 'updated_at' =>now()],
        ];

        Matiere::insert($matieres);
    }
}

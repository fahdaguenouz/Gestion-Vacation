<?php

namespace Database\Seeders;

use App\Models\EtablissementType;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class EtablissementTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $associations = [
            // Each establishment gets a primary type
            ['CodeEtablissement' => '04410T', 'IdType' => 1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04411U', 'IdType' => 1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04412V', 'IdType' => 1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04413W', 'IdType' => 2,'created_at' => now(), 'updated_at' =>now()], // Example of a secondary type
            ['CodeEtablissement' => '04414X', 'IdType' => 3,'created_at' => now(), 'updated_at' =>now()], // College type
            ['CodeEtablissement' => '04415Y', 'IdType' => 2,'created_at' => now(), 'updated_at' =>now()], // Secondary
            // Adding multiple types to some establishments,'created_at' => now(), 'updated_at' =>now()
            ['CodeEtablissement' => '04416Z', 'IdType' => 1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04416Z', 'IdType' => 2,'created_at' => now(), 'updated_at' =>now()], // IMAM ALGHAZALI also as Secondary
            ['CodeEtablissement' => '04417A', 'IdType' => 3,'created_at' => now(), 'updated_at' =>now()], // IMAM ALI as College
            ['CodeEtablissement' => '04418B', 'IdType' => 1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04419C', 'IdType' => 2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04421E', 'IdType' => 3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04422F', 'IdType' => 1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04423G', 'IdType' => 2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04424H', 'IdType' => 3,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04425J', 'IdType' => 1,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04426K', 'IdType' => 2,'created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04427L', 'IdType' => 3,'created_at' => now(), 'updated_at' =>now()],
            [
                'CodeEtablissement' => '04418B',
                'IdType' => 2,'created_at' => now(), 'updated_at' =>now() // Adding Secondaire to ABDELKRIM AL KHATTABI as well
            ],
            [
                'CodeEtablissement' => '04419C',
                'IdType' => 3,'created_at' => now(), 'updated_at' =>now() // AL KAWAKIB as Collège
            ],
            [
                'CodeEtablissement' => '04421E',
                'IdType' => 1,'created_at' => now(), 'updated_at' =>now() // AL MASSIRA AL KHADRA also as Primaire
            ],
            [
                'CodeEtablissement' => '04422F',
                'IdType' => 2 ,'created_at' => now(), 'updated_at' =>now()// AL INBIAAT as Secondaire
            ],
            [
                'CodeEtablissement' => '04423G',
                'IdType' => 1 ,'created_at' => now(), 'updated_at' =>now()// IBNOU BASSAM also as Primaire
            ],
            [
                'CodeEtablissement' => '04424H',
                'IdType' => 1 ,'created_at' => now(), 'updated_at' =>now()// 11 JANVIER as Primaire
            ],
            [
                'CodeEtablissement' => '04425J',
                'IdType' => 2 ,'created_at' => now(), 'updated_at' =>now()// MELOUIYA as Secondaire
            ],
            [
                'CodeEtablissement' => '04426K',
                'IdType' => 3 ,'created_at' => now(), 'updated_at' =>now()// BNI YAZNASSEN as Collège
            ],
            [
                'CodeEtablissement' => '04427L',
                'IdType' => 1 ,'created_at' => now(), 'updated_at' =>now()// AL WAFAE as Primaire
            ],
        ];

        EtablissementType::insert($associations);
    }
}

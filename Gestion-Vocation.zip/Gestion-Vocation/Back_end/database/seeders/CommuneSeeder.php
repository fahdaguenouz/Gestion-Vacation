<?php

namespace Database\Seeders;

use App\Models\Commune;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class CommuneSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        
        $communes = [
            ['CodeCommune' => '1130101', 'LibelleFr' => 'Ahfir (Mun.)', 'LibelleAr' => 'احفير (البلدية)','created_at' => now(), 'updated_at' =>now()],
            ['CodeCommune' => '1130105', 'LibelleFr' => 'Ain Erreggada (Mun.)', 'LibelleAr' => 'عين الركادة (البلدية)','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130107', 'LibelleFr' => 'Aklim (Mun.)', 'LibelleAr' => 'اكليم (البلدية)','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130109', 'LibelleFr' => 'Berkane (Mun.)', 'LibelleAr' => 'بركان (البلدية)','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130125', 'LibelleFr' => 'Saidia (Mun.)', 'LibelleAr' => 'السعيدية (البلدية)','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130129', 'LibelleFr' => 'Sidi Slimane Echcharraa (Mun.)', 'LibelleAr' => 'سيدي سليمان - الشراعة (البلدية)','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130301', 'LibelleFr' => 'Aghbal', 'LibelleAr' => 'اغبال','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130307', 'LibelleFr' => 'Fezouane', 'LibelleAr' => 'فزوان','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130309', 'LibelleFr' => 'Laatamna', 'LibelleAr' => 'لعثامنة','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130311', 'LibelleFr' => 'Madagh', 'LibelleAr' => 'مداغ','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130503', 'LibelleFr' => 'Boughriba', 'LibelleAr' => 'بوغريبة','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130505', 'LibelleFr' => 'Chouihia', 'LibelleAr' => 'شويحية','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130513', 'LibelleFr' => 'Rislane', 'LibelleAr' => 'رسلان','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130515', 'LibelleFr' => 'Sidi Bouhria', 'LibelleAr' => 'سيدي بوهرية','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130517', 'LibelleFr' => 'Tafoughalt', 'LibelleAr' => 'تافوغالت','created_at' => now(), 'updated_at' => now()],
            ['CodeCommune' => '1130519', 'LibelleFr' => 'Zegzel', 'LibelleAr' => 'زكزل','created_at' => now(), 'updated_at' => now()],
        ];
        Commune::insert($communes);

    }
}

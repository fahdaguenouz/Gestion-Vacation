<?php

namespace Database\Seeders;

use App\Models\Grade;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GradeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $grades = [
            ['CodeGrade' => 'GRD001', 'LibelleAr' => 'معلم أول', 'LibelleFr' => 'Enseignant primaire','created_at' => now(), 'updated_at' =>now()],
            ['CodeGrade' => 'GRD002', 'LibelleAr' => 'معلم ثانوي', 'LibelleFr' => 'Enseignant secondaire','created_at' => now(), 'updated_at' =>now()],
            ['CodeGrade' => 'GRD003', 'LibelleAr' => 'أستاذ', 'LibelleFr' => 'Professeur','created_at' => now(), 'updated_at' =>now()],
            ['CodeGrade' => 'GRD004', 'LibelleAr' => 'مدير', 'LibelleFr' => 'Directeur','created_at' => now(), 'updated_at' =>now()],
            ['CodeGrade' => 'GRD005', 'LibelleAr' => 'نائب المدير', 'LibelleFr' => 'Directeur adjoint','created_at' => now(), 'updated_at' =>now()],
            ['CodeGrade' => 'GRD006', 'LibelleAr' => 'مشرف تربوي', 'LibelleFr' => 'Superviseur éducatif','created_at' => now(), 'updated_at' =>now()],
            ['CodeGrade' => 'GRD007', 'LibelleAr' => 'مستشار التوجيه', 'LibelleFr' => 'Conseiller d\'orientation','created_at' => now(), 'updated_at' =>now()],
            ['CodeGrade' => 'GRD008', 'LibelleAr' => 'مستشار تربوي', 'LibelleFr' => 'Conseiller pédagogique','created_at' => now(), 'updated_at' =>now()],
            ['CodeGrade' => 'GRD009', 'LibelleAr' => 'معلم مساعد', 'LibelleFr' => 'Enseignant assistant','created_at' => now(), 'updated_at' =>now()],
            ['CodeGrade' => 'GRD010', 'LibelleAr' => 'أستاذ مساعد', 'LibelleFr' => 'Professeur assistant','created_at' => now(), 'updated_at' =>now()],
        ];

        Grade::insert($grades);
    }
}

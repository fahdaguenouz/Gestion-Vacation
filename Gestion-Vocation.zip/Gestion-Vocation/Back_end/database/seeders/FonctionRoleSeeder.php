<?php

namespace Database\Seeders;

use App\Models\FonctionRole;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FonctionRoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $fonctionRoles = [
            ['CodeFonct' => 'FNC001', 'LibelleAr' => 'مدير المؤسسة', 'LibelleFr' => 'Directeur de l\'établissement','created_at' => now(), 'updated_at' =>now()],
            ['CodeFonct' => 'FNC002', 'LibelleAr' => 'نائب المدير', 'LibelleFr' => 'Directeur adjoint','created_at' => now(), 'updated_at' =>now()],
            ['CodeFonct' => 'FNC003', 'LibelleAr' => 'السكرتير', 'LibelleFr' => 'Secrétaire','created_at' => now(), 'updated_at' =>now()],
            ['CodeFonct' => 'FNC004', 'LibelleAr' => 'المرشد التربوي', 'LibelleFr' => 'Conseiller pédagogique','created_at' => now(), 'updated_at' =>now()],
            ['CodeFonct' => 'FNC005', 'LibelleAr' => 'مشرف الداخلية', 'LibelleFr' => 'Surveillant général','created_at' => now(), 'updated_at' =>now()],
            ['CodeFonct' => 'FNC006', 'LibelleAr' => 'معلم', 'LibelleFr' => 'Enseignant','created_at' => now(), 'updated_at' =>now()],
            ['CodeFonct' => 'FNC007', 'LibelleAr' => 'أمين المكتبة', 'LibelleFr' => 'Bibliothécaire','created_at' => now(), 'updated_at' =>now()],
            ['CodeFonct' => 'FNC008', 'LibelleAr' => 'المحاسب', 'LibelleFr' => 'Comptable','created_at' => now(), 'updated_at' =>now()],
            ['CodeFonct' => 'FNC009', 'LibelleAr' => 'المستشار التربوي', 'LibelleFr' => 'Conseiller d\'éducation','created_at' => now(), 'updated_at' =>now()],
            ['CodeFonct' => 'FNC010', 'LibelleAr' => 'تقني المعلوميات', 'LibelleFr' => 'Technicien informatique','created_at' => now(), 'updated_at' =>now()],
        ];

        FonctionRole::insert($fonctionRoles);
    }
}

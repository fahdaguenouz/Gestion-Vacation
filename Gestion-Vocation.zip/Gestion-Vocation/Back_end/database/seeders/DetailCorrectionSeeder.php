<?php

namespace Database\Seeders;

use App\Models\DetailCorrection;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DetailCorrectionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $detailCorrections = [
            ['CodeDoti' => 'P001', 'id_jury' => 1, 'taux' => 0.10, 'nombre_de_copie' => 100,'IdTypePaiement'=>1, 'prix_de_copie' => 1.50, 'date_de_correction' => now(),'created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P002', 'id_jury' => 2, 'taux' => 0.15, 'nombre_de_copie' => 150,'IdTypePaiement'=>2, 'prix_de_copie' => 2.00, 'date_de_correction' => now(),'created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P003', 'id_jury' => 3, 'taux' => 0.20, 'nombre_de_copie' => 200,'IdTypePaiement'=>3, 'prix_de_copie' => 2.50, 'date_de_correction' => now(),'created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P004', 'id_jury' => 4, 'taux' => 0.12, 'nombre_de_copie' => 120,'IdTypePaiement'=>2, 'prix_de_copie' => 1.75, 'date_de_correction' => now(),'created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P005', 'id_jury' => 5, 'taux' => 0.18, 'nombre_de_copie' => 180,'IdTypePaiement'=>1, 'prix_de_copie' => 2.25, 'date_de_correction' => now(),'created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P006', 'id_jury' => 6, 'taux' => 0.10, 'nombre_de_copie' => 110,'IdTypePaiement'=>3, 'prix_de_copie' => 1.50, 'date_de_correction' => now(),'created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P007', 'id_jury' => 7, 'taux' => 0.14, 'nombre_de_copie' => 140,'IdTypePaiement'=>3, 'prix_de_copie' => 2.00, 'date_de_correction' => now(),'created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P008', 'id_jury' => 8, 'taux' => 0.16, 'nombre_de_copie' => 160,'IdTypePaiement'=>1, 'prix_de_copie' => 2.10, 'date_de_correction' => now(),'created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P009', 'id_jury' => 9, 'taux' => 0.19, 'nombre_de_copie' => 190,'IdTypePaiement'=>1, 'prix_de_copie' => 2.40, 'date_de_correction' => now(),'created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P010', 'id_jury' => 10, 'taux' => 0.11, 'nombre_de_copie' => 130,'IdTypePaiement'=>2, 'prix_de_copie' => 1.80, 'date_de_correction' => now(),'created_at' => now(), 'updated_at' =>now()],
        ];

        DetailCorrection::insert($detailCorrections);
    }
}

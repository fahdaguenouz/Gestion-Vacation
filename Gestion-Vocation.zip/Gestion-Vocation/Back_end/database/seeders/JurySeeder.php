<?php

namespace Database\Seeders;

use App\Models\Jury;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class JurySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $juries = [
            ['NumJury' => 'JRY001', 'Matiere_id'=>1,'CodeMatiere' => 'MAT001', 'NombreCopies' => 150,'created_at' => now(), 'updated_at' =>now()],
            ['NumJury' => 'JRY002', 'Matiere_id'=>2,'CodeMatiere' => 'MAT002', 'NombreCopies' => 120,'created_at' => now(), 'updated_at' =>now()],
            ['NumJury' => 'JRY003', 'Matiere_id'=>3,'CodeMatiere' => 'MAT003', 'NombreCopies' => 130,'created_at' => now(), 'updated_at' =>now()],
            ['NumJury' => 'JRY004', 'Matiere_id'=>4,'CodeMatiere' => 'MAT004', 'NombreCopies' => 140,'created_at' => now(), 'updated_at' =>now()],
            ['NumJury' => 'JRY005', 'Matiere_id'=>5,'CodeMatiere' => 'MAT005', 'NombreCopies' => 110,'created_at' => now(), 'updated_at' =>now()],
            ['NumJury' => 'JRY006', 'Matiere_id'=>6,'CodeMatiere' => 'MAT006', 'NombreCopies' => 125,'created_at' => now(), 'updated_at' =>now()],
            ['NumJury' => 'JRY007', 'Matiere_id'=>7,'CodeMatiere' => 'MAT007', 'NombreCopies' => 115,'created_at' => now(), 'updated_at' =>now()],
            ['NumJury' => 'JRY008', 'Matiere_id'=>8,'CodeMatiere' => 'MAT008', 'NombreCopies' => 135,'created_at' => now(), 'updated_at' =>now()],
            ['NumJury' => 'JRY009', 'Matiere_id'=>9,'CodeMatiere' => 'MAT009', 'NombreCopies' => 145,'created_at' => now(), 'updated_at' =>now()],
            ['NumJury' => 'JRY010', 'Matiere_id'=>10,'CodeMatiere' => 'MAT010', 'NombreCopies' => 155,'created_at' => now(), 'updated_at' =>now()],
        ];

        Jury::insert($juries);
    }
}

<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {

        User::factory()->create([
            'name' => "Fahd Aguenouz",
            'email' => 'fahd@gmail.com',
            'password' => "fahd123456789",

            // Add other payment types if necessary
        ]);
        // $this->call([
        //     CommuneSeeder::class,
        //     TypeEtablissementSeeder::class,
        //     GradeSeeder::class,
        //     FonctionRoleSeeder::class,
        //     TypePaiementSeeder::class,
        //     MatiereSeeder::class,
        //     BudgetSeeder::class,
        //     EtablissementScolaireSeeder::class,
        //     PersonnelSeeder::class,
        //     JurySeeder::class,
        //     EtablissementTypeSeeder::class,
        //     DetailCorrectionSeeder::class,
        // ]);


    }
}

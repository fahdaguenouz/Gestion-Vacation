<?php

namespace Database\Seeders;

use App\Models\Personnel;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PersonnelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $personnels = [
            ['CodeDoti' => 'P001', 'Cin' => 'AB3456', 'LibelleFr' => 'Laila Chraibi', 'LibelleAr' => 'ليلى الشرايبي', 'CodeEtablissement' => '04410T', 'CodeGrade' => 'GRD001', 'CodeFonct' => 'FNC006', 'Matiere_id' => 1, 'Rib' => '100000000001', 'FichierRib' => 'rib_laila.pdf', 'Taux' => 20.5,'status' => 'active','created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P002', 'Cin' => 'BC4567', 'LibelleFr' => 'Omar Farouk', 'LibelleAr' => 'عمر فاروق','CodeEtablissement' => '04411U',  'CodeGrade' => 'GRD002', 'CodeFonct' => 'FNC007', 'Matiere_id' => 2, 'Rib' => '100000000002', 'FichierRib' => 'rib_omar.pdf', 'Taux' => 22.0,'status' => 'active','created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P003', 'Cin' => 'CD5678', 'LibelleFr' => 'Youssef Amrani', 'LibelleAr' => 'يوسف العمراني', 'CodeEtablissement' => '04412V', 'CodeGrade' => 'GRD003', 'CodeFonct' => 'FNC008', 'Matiere_id' => 3, 'Rib' => '100000000003', 'FichierRib' => 'rib_youssef.pdf', 'Taux' => 23.5,'status' => 'active','created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P004', 'Cin' => 'DE6789', 'LibelleFr' => 'Sara Belkadi', 'LibelleAr' => 'سارة بلقاضي', 'CodeEtablissement' => '04413W', 'CodeGrade' => 'GRD004', 'CodeFonct' => 'FNC009', 'Matiere_id' => 4, 'Rib' => '100000000004', 'FichierRib' => 'rib_sara.pdf', 'Taux' => 24.0,'status' => 'active','created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P005', 'Cin' => 'EF7890', 'LibelleFr' => 'Khalid Essaadi', 'LibelleAr' => 'خالد السعدي','CodeEtablissement' => '04414X',  'CodeGrade' => 'GRD005', 'CodeFonct' => 'FNC001', 'Matiere_id' => 5, 'Rib' => '100000000005', 'FichierRib' => 'rib_khalid.pdf', 'Taux' => 21.0,'status' => 'active','created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P006', 'Cin' => 'FG8901', 'LibelleFr' => 'Mounia Rmiki', 'LibelleAr' => 'منية الرميكي','CodeEtablissement' => '04415Y',  'CodeGrade' => 'GRD006', 'CodeFonct' => 'FNC002', 'Matiere_id' => 6, 'Rib' => '100000000006', 'FichierRib' => 'rib_mounia.pdf', 'Taux' => 20.0,'status' => 'active','created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P007', 'Cin' => 'GH9012', 'LibelleFr' => 'Amine Kabbaj', 'LibelleAr' => 'أمين كباج', 'CodeEtablissement' => '04417A', 'CodeGrade' => 'GRD007', 'CodeFonct' => 'FNC003', 'Matiere_id' => 7, 'Rib' => '100000000007', 'FichierRib' => 'rib_amine.pdf', 'Taux' => 22.5,'status' => 'active','created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P008', 'Cin' => 'HI0123', 'LibelleFr' => 'Fatima Zahra Akdim', 'LibelleAr' => 'فاطمة الزهراء أكديم','CodeEtablissement' => '04418B',  'CodeGrade' => 'GRD008', 'CodeFonct' => 'FNC004', 'Matiere_id' => 8, 'Rib' => '100000000008', 'FichierRib' => 'rib_fatimazahra.pdf', 'Taux' => 23.0,'status' => 'active','created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P009', 'Cin' => 'IJ1234', 'LibelleFr' => 'Abdelali Nassiri', 'LibelleAr' => 'عبدالعالي ناصري','CodeEtablissement' => '04419C',  'CodeGrade' => 'GRD009', 'CodeFonct' => 'FNC005', 'Matiere_id' => 9, 'Rib' => '100000000009', 'FichierRib' => 'rib_abdelali.pdf', 'Taux' => 24.5,'status' => 'active','created_at' => now(), 'updated_at' =>now()],
            ['CodeDoti' => 'P010', 'Cin' => 'JK2345', 'LibelleFr' => 'Nadia El Idrissi', 'LibelleAr' => 'نادية الإدريسي', 'CodeEtablissement' => '04421E', 'CodeGrade' => 'GRD010', 'CodeFonct' => 'FNC010', 'Matiere_id' => 10, 'Rib' => '100000000010', 'FichierRib' => 'rib_nadia.pdf', 'Taux' => 25.0,'status' => 'active','created_at' => now(), 'updated_at' =>now()]
        ];

        Personnel::insert($personnels);
    }
}

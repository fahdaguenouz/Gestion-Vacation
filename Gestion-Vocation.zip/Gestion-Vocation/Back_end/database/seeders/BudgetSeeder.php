<?php

namespace Database\Seeders;

use App\Models\Budget;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BudgetSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void

    {

        $budgets = [
            ['IdTypePaiement' => 1, 'MontantInitial' => 1000, 'Date' => now(), 'anne' => now()->year, 'ResteDuMontant' => 750,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 2, 'MontantInitial' => 800, 'Date' => now(), 'anne' => now()->year, 'ResteDuMontant' => 800,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 1, 'MontantInitial' => 2500, 'Date' => now(), 'anne' => now()->year, 'ResteDuMontant' => 1250,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 3, 'MontantInitial' => 1500, 'Date' => now(), 'anne' => now()->year, 'ResteDuMontant' => 1000,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 1, 'MontantInitial' => 3000, 'Date' => now(), 'anne' => now()->year, 'ResteDuMontant' => 1500,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 1, 'MontantInitial' => 500, 'Date' => now(), 'anne' => now()->year, 'ResteDuMontant' => 250,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 2, 'MontantInitial' => 700, 'Date' => now(), 'anne' => now()->year, 'ResteDuMontant' => 350,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 3, 'MontantInitial' => 2000, 'Date' => now(), 'anne' => now()->year, 'ResteDuMontant' => 1000,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 2, 'MontantInitial' => 1200, 'Date' => now(), 'anne' => now()->year, 'ResteDuMontant' => 600,'created_at' => now(), 'updated_at' =>now()],
            ['IdTypePaiement' => 3, 'MontantInitial' => 900, 'Date' => now(), 'anne' => now()->year, 'ResteDuMontant' => 450,'created_at' => now(), 'updated_at' =>now()],
        ];

        DB::table('budgets')->insert($budgets);

    }
}

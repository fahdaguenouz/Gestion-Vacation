<?php

namespace Database\Seeders;

use App\Models\EtablissementScolaire;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EtablissementScolaireSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
       
        $etablissements = [
            ['CodeEtablissement' => '04410T', 'LibelleFr' => 'SALMANE EL FARISSI', 'LibelleAr' => 'سلمان الفارسي', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04411U', 'LibelleFr' => 'ELLAYMOUN', 'LibelleAr' => 'الليمون', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04412V', 'LibelleFr' => 'IDRISS 2', 'LibelleAr' => 'ادريس الثاني', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04413W', 'LibelleFr' => 'IBNOU ZAIDOUNE', 'LibelleAr' => 'ابن زيدون', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04414X', 'LibelleFr' => 'ASMAE BINT ABI BAKR', 'LibelleAr' => 'أسماء بنت أبي بكر', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04415Y', 'LibelleFr' => 'IBN HANI ELANDALOUSSI', 'LibelleAr' => 'ابن هانئ الأندلسي', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04416Z', 'LibelleFr' => 'IMAM ALGHAZALI', 'LibelleAr' => 'الإمام الغزالي', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04417A', 'LibelleFr' => 'IMAM ALI', 'LibelleAr' => 'الإمام علي', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04418B', 'LibelleFr' => 'ABDELKRIM AL KHATTABI', 'LibelleAr' => 'عبد الكريم الخطابي', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04419C', 'LibelleFr' => 'AL KAWAKIB', 'LibelleAr' => 'الكواكب', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04421E', 'LibelleFr' => 'AL MASSIRA AL KHADRA', 'LibelleAr' => 'المسيرة الخضراء', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04422F', 'LibelleFr' => 'AL INBIAAT', 'LibelleAr' => 'الإنبعاث', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04423G', 'LibelleFr' => 'IBNOU BASSAM', 'LibelleAr' => 'ابن بسام', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04424H', 'LibelleFr' => '11 JANVIER', 'LibelleAr' => '11 يناير', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04425J', 'LibelleFr' => 'MELOUIYA', 'LibelleAr' => 'ملوية', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04426K', 'LibelleFr' => 'BNI YAZNASSEN', 'LibelleAr' => 'بني يزناسن', 'CodeCommune' => '1130109','created_at' => now(), 'updated_at' =>now()],
            ['CodeEtablissement' => '04427L', 'LibelleFr' => 'AL WAFAE', 'LibelleAr' => 'الوفاء', 'CodeCommune' => '1130101','created_at' => now(), 'updated_at' =>now()],
        ];
        EtablissementScolaire::insert($etablissements);
    }
}

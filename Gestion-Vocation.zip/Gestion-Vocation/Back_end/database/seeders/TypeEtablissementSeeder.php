<?php

namespace Database\Seeders;

use App\Models\TypeEtablissement;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TypeEtablissementSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $types = [
            ['IdType' => 1, 'LibelleType' => 'Primaire','created_at' => now(), 'updated_at' =>now()],
            ['IdType' => 2, 'LibelleType' => 'Secondaire','created_at' => now(), 'updated_at' =>now()],
            ['IdType' => 3, 'LibelleType' => 'Collège','created_at' => now(), 'updated_at' =>now()]
        ];

        TypeEtablissement::insert($types);
    }
}

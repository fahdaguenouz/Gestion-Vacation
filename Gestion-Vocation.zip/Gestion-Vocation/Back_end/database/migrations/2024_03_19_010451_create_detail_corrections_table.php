<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('detail_corrections', function (Blueprint $table) {
            $table->id();
            $table->string('CodeDoti');
            $table->unsignedBigInteger('id_jury');
            $table->decimal('taux', 8, 2);
            $table->integer('nombre_de_copie');
            $table->string('IdTypePaiement');
            $table->decimal('prix_de_copie', 8, 2);
            $table->date('date_de_correction');
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('detail_corrections');
    }
};

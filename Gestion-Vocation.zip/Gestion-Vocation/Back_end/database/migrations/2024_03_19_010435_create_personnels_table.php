<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('personnels', function (Blueprint $table) {

            $table->string('CodeDoti')->primary();
            $table->string('Cin')->unique();
            $table->string('LibelleFr');
            $table->string('LibelleAr');
            $table->string('CodeEtablissement');
            $table->string('CodeGrade'); // Keep as placeholders for foreign keys
            $table->string('CodeFonct'); // Keep as placeholders for foreign keys
            $table->unsignedBigInteger('Matiere_id'); // Keep as placeholders for foreign keys
            $table->string('Rib');
            $table->string('FichierRib');
            $table->decimal('Taux', 8, 2);
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('personnels');
    }
};

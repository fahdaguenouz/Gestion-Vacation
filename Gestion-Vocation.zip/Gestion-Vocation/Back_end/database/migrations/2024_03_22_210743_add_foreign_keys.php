<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('etablissement_scolaires', function (Blueprint $table) {
            $table->foreign('CodeCommune')->references('CodeCommune')->on('communes')->onUpdate('cascade');
        });
        Schema::table('etablissement_types', function (Blueprint $table) {
            $table->foreign('CodeEtablissement')->references('CodeEtablissement')->on('etablissement_scolaires')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('IdType')->references('IdType')->on('type_etablissements')->onDelete('cascade')->onUpdate('cascade');
        });
        Schema::table('matieres', function (Blueprint $table) {
            $table->foreign('IdTypePaiement')->references('IdTypePaiement')->on('type_paiements')->onUpdate('cascade');
        });


        Schema::table('personnels', function (Blueprint $table) {
            $table->foreign('CodeEtablissement')->references('CodeEtablissement')->on('etablissement_scolaires')->onUpdate('cascade');
            $table->foreign('CodeGrade')->references('CodeGrade')->on('grades')->onUpdate('cascade');
            $table->foreign('CodeFonct')->references('CodeFonct')->on('fonction_roles')->onUpdate('cascade');
            $table->foreign('Matiere_id')->references('id')->on('matieres')->onUpdate('cascade');
        });

        // Assuming there's a detail_corrections table that needs foreign keys to personnels and juries
        Schema::table('detail_corrections', function (Blueprint $table) {

            $table->foreign('CodeDoti')->references('CodeDoti')->on('personnels')->onUpdate('cascade');
            $table->foreign('id_jury')->references('id')->on('juries')->onUpdate('cascade');
            $table->foreign('IdTypePaiement')->references('IdTypePaiement')->on('type_paiements')->onUpdate('cascade'); // For prix_de_copie
        });

        // If there's a personnel_taux_histories table for tracking taux history
        Schema::table('taux_personnel_histories', function (Blueprint $table) {
            $table->foreign('CodeDoti')->references('CodeDoti')->on('personnels')->onUpdate('cascade');
        });

        Schema::table('juries', function (Blueprint $table) {
            $table->foreign('Matiere_id')->references('id')->on('matieres')->onUpdate('cascade');
        });
        Schema::table('budgets', function (Blueprint $table) {
            $table->foreign('IdTypePaiement')->references('IdTypePaiement')->on('type_paiements')->onUpdate('cascade');
        });
    }

    public function down()
    {
        Schema::table('etablissement_scolaires', function (Blueprint $table) {
            $table->dropForeign(['CodeCommune']);
        });

        Schema::table('personnels', function (Blueprint $table) {
            $table->dropForeign(['CodeEtablissement']);
            $table->dropForeign(['CodeGrade']);
            $table->dropForeign(['CodeFonct']);
            $table->dropForeign(['Matiere_id']);
          });

          Schema::table('juries', function (Blueprint $table) {
              $table->dropForeign(['Matiere_id']);
          });
        Schema::table('detail_corrections', function (Blueprint $table) {
            $table->dropForeign(['CodeDoti']);
            $table->dropForeign(['id_jury']);
            $table->dropForeign(['IdTypePaiement']);
        });

        Schema::table('taux_personnel_histories', function (Blueprint $table) {
            $table->dropForeign(['CodeDoti']);
        });
        Schema::table('budgets', function (Blueprint $table) {
            $table->dropForeign(['IdTypePaiement']);
        });
    }
};

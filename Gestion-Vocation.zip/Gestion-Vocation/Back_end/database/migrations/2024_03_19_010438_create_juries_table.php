<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('juries', function (Blueprint $table) {

            $table->id();
            $table->string('NumJury');
            $table->string('CodeMatiere');
            $table->unsignedBigInteger('Matiere_id');
            $table->integer('NombreCopies');

            // Define unique constraint for combination of NumJury and CodeMatiere
            $table->unique(['NumJury', 'CodeMatiere']);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('juries');
    }
};

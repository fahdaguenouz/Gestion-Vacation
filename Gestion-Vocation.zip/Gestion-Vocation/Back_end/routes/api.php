<?php

use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\BudgetController;
use App\Http\Controllers\DetailCorrectionController;
use App\Http\Controllers\EtablissementScolaireController;
use App\Http\Controllers\FonctionRoleController;
use App\Http\Controllers\GradeController;
use App\Http\Controllers\JuryController;
use App\Http\Controllers\MatierController;
use App\Http\Controllers\PersonnelController;
use App\Http\Controllers\TypePaiementController;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/users/get-user/{user}', [UserController::class, 'show']);
Route::middleware(['auth:sanctum'])->get('/get-users', [UserController::class, 'index']);
Route::middleware(['auth:sanctum'])->get('/get-personnels', [PersonnelController::class, 'index']);
Route::middleware(['auth:sanctum'])->get('/get-budgets', [BudgetController::class, 'index']);
Route::middleware(['auth:sanctum'])->get('/get-matieres', [MatierController::class, 'index']);
Route::middleware(['auth:sanctum'])->get('/get-grades', [GradeController::class, 'index']);
Route::middleware(['auth:sanctum'])->get('/get-fonction-roles', [FonctionRoleController::class, 'index']);
Route::middleware(['auth:sanctum'])->get('/get-detail-corrections', [DetailCorrectionController::class, 'index']);
Route::middleware('auth:sanctum')->get('/user/get-logged-in-user',[UserController::class, 'logged_in_user']);
Route::middleware(['auth:sanctum'])->get('/get-etblissement-scolaires', [EtablissementScolaireController::class, 'index']);
Route::middleware(['auth:sanctum'])->get('/get-type-paiement', [TypePaiementController::class, 'index']);
Route::middleware(['auth:sanctum'])->get('/get-jury', [JuryController::class, 'index']);


Route::get('/personnel/{CodeDoti}/download-rib', [PersonnelController::class, 'downloadRib']);


Route::middleware('auth:sanctum')->get('/personnel/get-personnel/{CodeDoti}', [PersonnelController::class, 'show']);






Route::apiResources([
    'Ajouter-Personnel' => PersonnelController::class ,
    'budgets' =>BudgetController::class,
    'Ajouter-Users' =>UserController::class,
    'Ajouter-Detail-correction'=>DetailCorrectionController::class,
    'Ajouter-Budget'=>BudgetController::class,
    'Ajouter-Jury'=>JuryController::class
]);


Route::delete('/delete-personnel/{personnel}', [PersonnelController::class, 'destroy'])->middleware('auth:sanctum');

Route::delete('/delete-User/{user}', [UserController::class, 'destroy'])->middleware('auth:sanctum');




Route::middleware('auth:sanctum')->put('/users/Update-User/{user}', [UserController::class, 'update']);
Route::middleware('auth:sanctum')->put('/personnel/Update-Personnel/{CodeDoti}', [PersonnelController::class, 'update']);
Route::middleware('auth:sanctum')->put('/budget/Update-Budget/{IdBudget}', [BudgetController::class, 'update']);
Route::middleware('auth:sanctum')->put('/jury/Update-jury/{NumJury}', [JuryController::class, 'update']);





Route::post('/login', [AuthenticatedSessionController::class, 'store']);
Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])
     ->middleware('auth:sanctum');
Route::get('/test-csrf', function () {
    return response()->json(['csrf' => csrf_token()]);
});

<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\TypePaiement;
use Illuminate\Http\Request;

class TypePaiementController extends Controller
{
    public function index()
    {
        $typePaiement = TypePaiement::all();

        // Return the list of users
        return response()->json($typePaiement);
    }

}

<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\FonctionRole;
use Illuminate\Http\Request;

class FonctionRoleController extends Controller
{
    public function index()
    {
        $fonction = FonctionRole::all();

        // Return the list of users
        return response()->json($fonction);
    }

}

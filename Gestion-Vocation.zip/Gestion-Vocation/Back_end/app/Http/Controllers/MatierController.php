<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Matiere;
use Illuminate\Http\Request;

class MatierController extends Controller
{
    public function index()
    {
        $matiers = Matiere::all();

        // Return the list of users
        return response()->json($matiers);
    }

}

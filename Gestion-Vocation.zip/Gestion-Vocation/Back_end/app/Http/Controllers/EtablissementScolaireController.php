<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\EtablissementScolaire;
use Illuminate\Http\Request;

class EtablissementScolaireController extends Controller
{
    function index()
{
    $Etablissement = EtablissementScolaire::all();
    return response()->json($Etablissement);
}
}

<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\StorePersonnelRequest;
use App\Http\Requests\UpdatePersonnelRequest;
use App\Http\Resources\PersonnelResource;
use App\Models\Personnel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;


class PersonnelController extends Controller
{


    public function store(StorePersonnelRequest $request)
    {
        \Log::info('Files in request:', $request->file());
        // Validate the request
        $validated = $request->validated();

        // Handle file upload for 'FichierRib' if it exists
        // Handle file upload for 'FichierRib' if it exists
        if ($request->hasFile('FichierRib') && $request->file('FichierRib')->isValid()) {
            \Log::info('FichierRib is present');
            $file = $request->file('FichierRib');
            $filename = time() . '_' . $file->getClientOriginalName();
            $path = $file->storeAs('public/ribs', $filename);
            $validated['FichierRib'] = $path;
        } else {
            \Log::error('No FichierRib uploaded or file is invalid');
        }


        // Create the Personnel record with the validated data
        $personnel = Personnel::create($validated);

        // Load relationships if necessary
        $personnel->load('grade', 'fonctionRole', 'matiere', 'etablissementScolaire');

        // Return the created personnel with its relationships, wrapped in a resource
        return new PersonnelResource($personnel);
    }

    function index()
    {
        $personnel = Personnel::with(['grade', 'fonctionRole', 'matiere', 'etablissementScolaire'])->get();
        return response()->json($personnel);
    }

    public function downloadRib($CodeDoti)
    {
        $personnel = Personnel::findOrFail($CodeDoti);
        $filePath = $personnel->FichierRib;

        if (!Storage::exists($filePath)) {
            abort(404);
        }

        $fileContent = Storage::get($filePath);
        $fileName = basename($filePath);

        // Return file content as a download response
        return response()->make($fileContent, 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="' . $fileName . '"'
        ]);
    }

    public function destroy($CodeDoti)
    {
        // Find the personnel by CodeDoti
        $personnel = Personnel::findOrFail($CodeDoti);

        // Check if a PDF file path is stored in the personnel record
        if (!empty($personnel->FichierRib)) {
            // Use Laravel's Storage facade to delete the file
            Storage::delete($personnel->FichierRib);
        }

        // Delete the personnel record
        $personnel->delete();

        // Return a response indicating success
        return response()->json(['message' => 'Personnel and associated PDF deleted successfully'], 200);
    }

    public function update(UpdatePersonnelRequest $request, $CodeDoti)
    {
        $personnel = Personnel::findOrFail($CodeDoti);

        // Handle file upload for 'FichierRib' if it exists and is valid
        if ($request->hasFile('FichierRib') && $request->file('FichierRib')->isValid()) {
            $file = $request->file('FichierRib');
            $filename = time() . '_' . $file->getClientOriginalName();
            $path = $file->storeAs('public/ribs', $filename);

            // Delete old file if exists
            if ($personnel->FichierRib && Storage::exists($personnel->FichierRib)) {
                Storage::delete($personnel->FichierRib);
            }

            // Update file path in validated data array
            $request->merge(['FichierRib' => $path]);
        }

        // Update the personnel with validated data from the request
        $personnel->update($request->all());
        
        // Reload the model to ensure all relations are fresh
        $personnel->load('grade', 'fonctionRole', 'matiere', 'etablissementScolaire');

        // Return the updated personnel as a resource
        return new PersonnelResource($personnel);
    }
    public function show(Personnel $CodeDoti)
    {
        return new PersonnelResource($CodeDoti);
    }


}

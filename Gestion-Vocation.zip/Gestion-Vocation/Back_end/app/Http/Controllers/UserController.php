<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        // Retrieve all users or implement your own logic for which users to retrieve
        $users = User::all();

        // Return the list of users
        return response()->json($users);
    }

    public function logged_in_user(Request $request)

{
    // Get the currently authenticated user
    $user = auth()->user();

    // Return the authenticated user's details using UserResource
    return new UserResource($user);
}

    public function store(StoreUserRequest $request)
    {
        $validated = $request->validated();
        $validated['password'] = Hash::make($validated['password']); // Hash password
        $user = User::create($validated);
        return new UserResource($user);
    }

    public function update(UpdateUserRequest $request, User $user)
    {
        $validated = $request->validated();
        if (isset ($validated['password'])) {
            $validated['password'] = Hash::make($validated['password']); // Hash new password if provided
        }
        $user->update($validated);
        return new UserResource($user);
    }

    public function destroy(User $user)
    {
        $user->delete();
        return response()->json(['message' => 'User deleted successfully']);
    }

    public function show(User $user)
    {
        return new UserResource($user);
    }
}

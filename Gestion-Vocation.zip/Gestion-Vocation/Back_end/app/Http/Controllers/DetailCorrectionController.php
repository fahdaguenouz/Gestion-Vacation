<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreDetailCorrectionRequest;
use App\Http\Resources\DetailCorrectionResource;
use App\Models\DetailCorrection;
use Illuminate\Http\Request;

class DetailCorrectionController extends Controller
{

    function index()
    {
        $detailCorrection = DetailCorrection::with(['typepaiement', 'jury', 'personnel'])->get();
        return response()->json($detailCorrection);
    }

    public function store(StoreDetailCorrectionRequest $request)
    {
        // The request is automatically validated at this point
        $detail = DetailCorrection::create($request->validated());

        // Optional: attach relationships if necessary
        // $detail->personnel()->associate($request->input('personnel_id'))->save();
        // $detail->jury()->associate($request->input('jury_id'))->save();
        // $detail->typepaiement()->associate($request->input('typepaiement_id'))->save();

        return  new DetailCorrectionResource($detail);
    }
}

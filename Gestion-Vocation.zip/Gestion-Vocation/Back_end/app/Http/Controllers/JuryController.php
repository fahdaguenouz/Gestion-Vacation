<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreJuryRequest;
use App\Http\Requests\UpdateJuryRequest;
use App\Http\Resources\JuryResource;
use App\Models\Jury;
use Illuminate\Http\Request;

class JuryController extends Controller
{
    public function index()
    {
        $jury = Jury::with('matiere')->get(); // Assurez-vous de charger la relation
        return response()->json($jury);
    }

    public function store(StoreJuryRequest $request)
{
    $juriesData = $request->get('juries');
    $errors = [];
    $createdJuries = [];

    foreach ($juriesData as $juryData) {
        $numJury = $juryData['NumJury'];
        $codeMatiere = $juryData['CodeMatiere'];
        $Matiere_id=$juryData['Matiere_id'];

        // Create the new jury record
        $jury = Jury::create([
            'NumJury' => $numJury,
            'CodeMatiere' => $codeMatiere,
            'Matiere_id'=>$Matiere_id,
            'NombreCopies' => $juryData['NombreCopies'],
        ]);

        $createdJuries[] = $jury;
    }

    return JuryResource::collection($createdJuries);
}


public function update(UpdateJuryRequest $request, Jury $Jury)
    {
        $validated = $request->validated();

        $Jury->update($validated);
        return new JuryResource($Jury);
    }

}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DetailCorrectionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request)
    {
         return [
            'id' => $this->id, // Assuming your model has an id
            'CodeDoti' => $this->CodeDoti,
            'NumJury' => $this->NumJury,
            'nombre_de_copie' => $this->nombre_de_copie,
            'IdTypePaiement' => $this->IdTypePaiement,
            'prix_de_copie' => $this->prix_de_copie,
            'date_de_correction' => $this->date_de_correction,
            'taux' => $this->taux, // Note: Make sure to match the case and spelling from the model
            // If you have relationships that you want to include, you can do it here. For example:
            // 'personnel' => new PersonnelResource($this->personnel),
            // 'jury' => new JuryResource($this->jury),
            // 'typePaiement' => new TypePaiementResource($this->typepaiement),
        ];
    }
}

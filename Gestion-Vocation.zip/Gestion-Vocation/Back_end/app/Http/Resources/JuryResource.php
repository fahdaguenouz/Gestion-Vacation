<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class JuryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {

            return [
                'NumJury' => $this->NumJury,
                'codeMatiere' => $this->CodeMatiere,
                'Matiere_id'=>$this->Matiere_id,
                'NombreCopies' => $this->NombreCopies,
                'matiere' => new MatiereResource($this->whenLoaded('matiere')), // Assuming you also have a MatiereResource
            ];
        }
}

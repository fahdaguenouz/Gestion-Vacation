<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class EtablissementScolaireResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'CodeEtablissement' => $this->CodeEtablissement,
            'LibelleAr' => $this->LibelleAr,
            'LibelleFr' => $this->LibelleFr,
            'commune' => new CommuneResource($this->commune),        ];

        }
}

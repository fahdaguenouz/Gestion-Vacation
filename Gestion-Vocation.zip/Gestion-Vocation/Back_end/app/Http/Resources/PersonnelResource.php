<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PersonnelResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request)
    {
        return [
            'codeDoti' => $this->CodeDoti,
            'cin' => $this->Cin,
            'libelleFr' => $this->LibelleFr,
            'libelleAr' => $this->LibelleAr,
            'etablissementScolaire' => $this->etablissementScolaire ? new EtablissementScolaireResource($this->etablissementScolaire) : null,
            'grade' => $this->grade ? new GradeResource($this->grade) : null,
            'fonctionRole' => $this->fonctionRole ? new FonctionRoleResource($this->fonctionRole) : null,
            'matiere' => $this->matiere ? new MatiereResource($this->matiere) : null,
            'rib' => $this->Rib,
            'FichierRib' => $this->FichierRib,
            'taux' => $this->Taux,
            'status' => $this->status,
        ];
    }
}

<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreDetailCorrectionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'CodeDoti'=>'required',
            'id_jury'=>'required',
            'nombre_de_copie'=>'required',
            'IdTypePaiement'=>'required',
            'prix_de_copie'=>'required',
            'date_de_correction'=>'required',
            'taux'=>'required',
        ];
    }
}

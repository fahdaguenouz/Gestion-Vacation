<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreJuryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules()
    {


            return [


                'juries.*.NumJury' => 'required|string|unique:juries,NumJury',
                'juries.*.CodeMatiere' => 'required|string|exists:matieres,CodeMatiere',
                'juries.*.Matiere_id' => 'required|integer', // Assuming you have a `matieres` table
                'juries.*.NombreCopies' => 'required|integer',
            ];

    }
}

<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdatePersonnelRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'LibelleFr' => 'nullable',
            'LibelleAr' => 'nullable',
            'FichierRib' => 'nullable|file|mimes:pdf,jpeg,png|max:2048',
            'etablissementScolaire' =>'nullable',
            'grade' =>'nullable',
            'fonctionRole' =>'nullable',
            'matiere' =>'nullable',
            'rib' =>'nullable|numeric|digits:24',
            'taux' =>'nullable',
            'status' =>'nullable',
        ];
    }
}

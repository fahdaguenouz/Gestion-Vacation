<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StorePersonnelRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'CodeDoti'=>'required|unique:personnels',
            'Cin'=>['required', 'regex:/^[A-Za-z]{1}[A-Za-z0-9]{1}\d{1,}[0-9]*$/','unique:personnels'],
            'LibelleFr'=>'required',
            'LibelleAr'=>'required',
            'CodeEtablissement'=>'required',
            'CodeGrade'=>'required',
            'CodeFonct'=>'required',
            'Matiere_id'=>'required',
            'Rib'=>'required|numeric|digits:24',
            'FichierRib' => 'required|file|mimes:pdf,jpeg,png|max:2048',
            'Taux'=> 'required|numeric|between:0,100',
        ];
    }
}

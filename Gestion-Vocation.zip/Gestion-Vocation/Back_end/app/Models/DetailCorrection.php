<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DetailCorrection extends Model
{
    use HasFactory;

    protected $fillable = ['id','CodeDoti', 'id_jury', 'taux', 'nombre_de_copie','IdTypePaiement', 'prix_de_copie', 'date_de_correction'];

    public function personnel()
    {
        return $this->belongsTo(Personnel::class, 'CodeDoti', 'CodeDoti');
    }

    public function jury()
    {
        return $this->belongsTo(Jury::class, 'id_jury', 'id');
    }
    public function typepaiement()
    {
        return $this->belongsTo(TypePaiement::class, 'IdTypePaiement', 'IdTypePaiement');
    }
}

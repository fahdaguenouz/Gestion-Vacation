<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Grade extends Model
{
    use HasFactory;
    protected $primaryKey = 'CodeGrade'; // Custom primary key

    // Tell Eloquent to not auto-increment this primary key
    public $incrementing = false;

    // If your primary key is not an integer, you should also specify its type
    protected $keyType = 'string';
    protected $fillable = ['CodeGrade', 'LibelleAr', 'LibelleFr'];

    public function personnels()
    {
        return $this->hasMany(Personnel::class, 'CodeGrade', 'CodeGrade');
    }
}

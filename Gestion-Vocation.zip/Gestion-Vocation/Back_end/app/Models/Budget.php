<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Budget extends Model
{
    use HasFactory;
    protected $primaryKey = 'IdBudget'; // Custom primary key



   
    protected $fillable = ['IdBudget', 'IdTypePaiement', 'MontantInitial', 'Date', 'anne', 'ResteDuMontant'];

    public function typePaiement()
{
    return $this->belongsTo(TypePaiement::class, 'IdTypePaiement', 'IdTypePaiement');
}


}

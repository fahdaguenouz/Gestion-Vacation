<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TauxPersonnelHistorie extends Model
{
    use HasFactory;
    protected $table = 'taux_personnel_histories';
    protected $fillable = ['CodeDoti', 'taux', 'effective_date'];

    public function personnel()
    {
        // Assuming 'CodeDoti' in 'personnel_taux_histories' table references 'CodeDoti' in 'personnels' table
        // and that 'CodeDoti' is the primary or a unique key in 'personnels'.
        return $this->belongsTo(Personnel::class, 'CodeDoti', 'CodeDoti');
    }
}

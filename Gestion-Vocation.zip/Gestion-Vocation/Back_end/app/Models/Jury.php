<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Jury extends Model
{
    use HasFactory;
    protected $fillable = ['id', 'NumJury', 'Matiere_id','CodeMatiere', 'NombreCopies'];

    public function matiere()
    {
        return $this->belongsTo(Matiere::class, 'Matiere_id', 'id');
    }

    public function detailCorrections()
    {
        return $this->hasMany(DetailCorrection::class, 'NumJury', 'NumJury');
    }
    
}

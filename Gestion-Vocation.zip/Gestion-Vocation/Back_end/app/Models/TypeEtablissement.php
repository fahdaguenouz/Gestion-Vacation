<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TypeEtablissement extends Model
{
    use HasFactory;
    protected $fillable = ['IdType', 'LibelleType'];

    public function etablissementsScolaires()
    {
        return $this->belongsToMany(EtablissementScolaire::class, 'etablissement_types', 'IdType', 'CodeEtablissement');
    }
}

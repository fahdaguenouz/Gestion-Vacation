<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TypePaiement extends Model
{
    use HasFactory;
    protected $fillable = ['IdTypePaiement', 'Libelle', 'PrixParCopie'];
    public function budgets()
    {
        return $this->hasMany(Budget::class, 'IdTypePaiement', 'IdTypePaiement');
    }

}

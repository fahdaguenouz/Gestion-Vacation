<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EtablissementScolaire extends Model
{
    use HasFactory;
    protected $primaryKey = 'CodeEtablissement'; // Custom primary key

    // Tell Eloquent to not auto-increment this primary key
    public $incrementing = false;

    // If your primary key is not an integer, you should also specify its type
    protected $keyType = 'string';
    protected $fillable = ['CodeEtablissement', 'LibelleAr', 'LibelleFr', 'CodeCommune'];

    public function commune()
    {
        return $this->belongsTo(Commune::class, 'CodeCommune', 'CodeCommune');
    }
    public function types()
    {
        return $this->belongsToMany(TypeEtablissement::class, 'etablissement_types', 'CodeEtablissement', 'IdType');
    }
}

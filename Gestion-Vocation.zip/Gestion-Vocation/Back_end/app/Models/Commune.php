<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Commune extends Model
{
    use HasFactory;
    protected $primaryKey = 'CodeCommune'; // Custom primary key

    // Tell Eloquent to not auto-increment this primary key
    public $incrementing = false;

    // If your primary key is not an integer, you should also specify its type
    protected $keyType = 'string';
    protected $fillable = ['CodeCommune','LibelleAr', 'LibelleFr'];

    public function etablissementScolaires()
    {
        return $this->hasMany(EtablissementScolaire::class, 'CodeCommune', 'CodeCommune');
     }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Matiere extends Model
{
    use HasFactory;

    protected $fillable = ['id','CodeMatiere', 'LibelleAr', 'LibelleFr'];

    public function juries()
    {
        return $this->hasMany(Jury::class, 'CodeMatiere', 'CodeMatiere');
    }

    public function personnels()
    {
        return $this->hasMany(Personnel::class, 'CodeMatiere', 'CodeMatiere');
    }
    public function typePaiement()
    {
        return $this->belongsTo(TypePaiement::class, 'IdTypePaiement', 'IdTypePaiement');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Personnel extends Model
{
    use HasFactory;
    protected $primaryKey = 'CodeDoti'; // Custom primary key

    // Tell Eloquent to not auto-increment this primary key
    public $incrementing = false;

    // If your primary key is not an integer, you should also specify its type
    protected $keyType = 'string';
    protected $fillable = ['CodeDoti', 'Cin', 'LibelleFr', 'LibelleAr', 'CodeEtablissement', 'CodeGrade', 'CodeFonct', 'Matiere_id', 'Rib', 'FichierRib', 'Taux', 'status'];

    public function grade()
    {
        return $this->belongsTo(Grade::class, 'CodeGrade', 'CodeGrade');
    }

    public function fonctionRole()
    {
        return $this->belongsTo(FonctionRole::class, 'CodeFonct', 'CodeFonct');
    }

    public function matiere()
    {
        return $this->belongsTo(Matiere::class, 'Matiere_id', 'id');
    }
    public function etablissementScolaire()
    {
        return $this->belongsTo(EtablissementScolaire::class, 'CodeEtablissement', 'CodeEtablissement');
    }

}
